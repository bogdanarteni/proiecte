package com.plotter;

import de.congrace.exp4j.UnknownFunctionException;
import de.congrace.exp4j.UnparsableExpressionException;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Optional;


public class FunctionPlotter extends Application {

    private Plot target;
    static String usrColor="RED";
    static Integer usrGirth=1;

    /**
     * Metoda main, punct de intrare in aplicatie
     *
     * @param args
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Metoda start
     *
     * @param stage: the JavaFX main stage of the application
     * @throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {

        // Layout principal & elementele initiale
        BorderPane layout = new BorderPane();
        Axes axes = new Axes(500, 500, -10, 10, 1, -10, 10, 1);
        HBox hbox = new HBox();
        hbox.setSpacing(10);
        target = new Plot("0", -10, 10, 1, axes);


        // Butoane si liste cu optiuni
        Button startButton = new Button("Start");
        Button resetButton = new Button("Reset");
        Button saveAsPNG = new Button("Save to .png");
        ObservableList<String> colorOptions = FXCollections.observableArrayList("RED", "GREEN", "BLUE", "CYAN", "MAGENTA", "ORANGE", "PINK", "YELLOW");
        ObservableList<Integer> strokeOptions = FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        ComboBox<String> comboBoxCulori = new ComboBox<>(colorOptions);
        ComboBox<Integer> comboBoxValori = new ComboBox<>(strokeOptions);
        comboBoxValori.setPromptText("Stroke");
        comboBoxCulori.setPromptText("Color");


        // Listener pe butonul 'Start'

        startButton.setOnAction(event -> {
            System.out.println("Start pressed!");
            TextInputDialog input = new TextInputDialog();
            input.setTitle("Expresie");
            input.setHeaderText("Introduceți expresia:");
            Optional<String> result = input.showAndWait();
            if (result.isPresent()) {
                System.out.println("Expresie: '" + result.get().trim() + "'");
                String parseResult = result.get().trim();
                try {
                    target.plot(parseResult);
                } catch (UnparsableExpressionException | UnknownFunctionException e) {
                    e.printStackTrace();
                }
            }
        });

        // Listener pentru schimbat culoarea axei desenate
        comboBoxCulori.valueProperty().addListener((observable, oldValue, newValue) -> {
            usrColor = String.valueOf(newValue);
        });

        // Listener pentru schimbarea grosimii axei desenate
        comboBoxValori.valueProperty().addListener((observable, oldValue, newValue) -> {
            usrGirth = newValue;
        });


        
        resetButton.setOnAction(event -> {
            System.out.println("Reset pressed!");
            try {
                target = new Plot("0", -10, 10, 1, axes);
                layout.setCenter(target);
            } catch (UnparsableExpressionException | UnknownFunctionException e) {
                e.printStackTrace();
            }
        });

        
        saveAsPNG.setOnAction(event -> {
            System.out.println("Saving...");
            layout.getTop().setVisible(false);
            target.saveAsPNG(layout);
            try {
                Desktop.getDesktop().open(new File("plotted_line.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            layout.getTop().setVisible(true);
        });

        
        hbox.getChildren().addAll(startButton, resetButton, saveAsPNG, comboBoxCulori, comboBoxValori);
        hbox.setPadding(new Insets(10));
        layout.setPrefSize(500, 500);
        layout.setCenter(target);
        layout.setTop(hbox);
        layout.setPadding(new Insets(20));
        stage.setTitle("Graph Line Plotter");
        stage.setScene(new Scene(layout));
        stage.show();
    }
}
