package com.plotter;

import de.congrace.exp4j.Calculable;
import de.congrace.exp4j.ExpressionBuilder;
import de.congrace.exp4j.UnknownFunctionException;
import de.congrace.exp4j.UnparsableExpressionException;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


public class Plot extends Pane {

    private Path path = new Path();
    public String functionToPlot;
    private Integer xMin, xMax, xInc;
    private Axes axes;

    /**
     * Constructor pentru obiectul Plot
     *
     * @param f    functia parsata
     * @param xMin valoarea minima a x din functie
     * @param xMax valoarea maxima a x din functie
     * @param xInc numarul cu care se incrementeaza x
     * @param axes axele de coordonate ale aplicatiei
     */
    public Plot(String f, Integer xMin, Integer xMax, Integer xInc, Axes axes) throws UnparsableExpressionException, UnknownFunctionException {

        path.setClip(new Rectangle(0, 0, axes.getPrefWidth(), axes.getPrefHeight()));

        this.functionToPlot = f;
        this.axes = axes;
        this.xMin = xMin;
        this.xMax = xMax;
        this.xInc = xInc;

        setMinSize(Pane.USE_PREF_SIZE, Pane.USE_PREF_SIZE);
        setPrefSize(axes.getPrefWidth(), axes.getPrefHeight());
        setMaxSize(Pane.USE_PREF_SIZE, Pane.USE_PREF_SIZE);

        getChildren().setAll(axes);
    }

    public void plot(String functionToPlot) throws UnparsableExpressionException, UnknownFunctionException {

        this.functionToPlot = functionToPlot;
        Integer x = xMin;
        Calculable expressionBuilder = new ExpressionBuilder(this.functionToPlot).withVariable("x", x).build();
        double y = expressionBuilder.calculate();
        Path buildeePath = new Path();
        buildeePath.setClip(new Rectangle(0, 0, axes.getPrefWidth(), axes.getPrefHeight()));
        buildeePath.getElements().add(new MoveTo(mapX(x, axes), mapY(y, axes)));
        x += xInc;

        while (x < xMax) {
            expressionBuilder = new ExpressionBuilder(this.functionToPlot).withVariable("x", x).build();
            y = expressionBuilder.calculate();
            buildeePath.getElements().add(new LineTo(mapX(x, axes), mapY(y, axes)));
            x += xInc;
        }

        buildeePath.setStroke(Color.valueOf(FunctionPlotter.usrColor));
        buildeePath.setStrokeWidth(FunctionPlotter.usrGirth);

        getChildren().addAll(buildeePath);
    }


    /**
     * Functia care modifica trasarea pe axa Ox
     *
     * @param x:    valoarea mapata
     * @param axes:
     * @return
     */
    private double mapX(double x, Axes axes) {
        double tx = axes.getPrefWidth() / 2;
        double sx = axes.getPrefWidth() /
                (axes.getXAxis().getUpperBound() -
                        axes.getXAxis().getLowerBound());

        return x * sx + tx;
    }

    /**
     * Functia care modifica trasarea pe axa Oy
     *
     * @param y
     * @param axes
     * @return
     */
    private double mapY(double y, Axes axes) {
        double ty = axes.getPrefHeight() / 2;
        double sy = axes.getPrefHeight() /
                (axes.getYAxis().getUpperBound() -
                        axes.getYAxis().getLowerBound());

        return -y * sy + ty;
    }

    /**
     * Returneaza linia desenata, pentru a i se schimba proprietatile
     *
     * @return
     */
    public Path getPath() {
        return path;
    }

    public void setPath(Path path) {
        this.path = path;
    }

    /**
     * Salveaza desenul curent intr-o imagine .png
     *
     * @param layout: layout-ul curent al aplicatiei
     */
    public void saveAsPNG(BorderPane layout) {
        WritableImage image = layout.snapshot(new SnapshotParameters(), null);
        File file = new File("plotted_line.png");
        try {
            ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
