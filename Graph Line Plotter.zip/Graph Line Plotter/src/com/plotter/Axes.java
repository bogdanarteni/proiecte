package com.plotter;

import javafx.beans.binding.Bindings;
import javafx.geometry.Side;
import javafx.scene.chart.NumberAxis;
import javafx.scene.layout.Pane;

public class Axes extends Pane {
    private NumberAxis xAxis;
    private NumberAxis yAxis;

    /**
     * Constructor pentru obiectul Axes
     *
     * @param width:     latime
     * @param height:    inaltime
     * @param xLow:      valoare minima pe Ox
     * @param xHi:       valoare maxima pe Ox
     * @param xTickUnit: gradatia pe Ox
     * @param yLow:      valoare minima pe Oy
     * @param yHi:       valoare maxima pe Oy
     * @param yTickUnit: gradatie pe Oy
     */
    public Axes(
            int width, int height,
            double xLow, double xHi, double xTickUnit,
            double yLow, double yHi, double yTickUnit
    ) {
        setMinSize(Pane.USE_PREF_SIZE, Pane.USE_PREF_SIZE);
        setPrefSize(width, height);
        setMaxSize(Pane.USE_PREF_SIZE, Pane.USE_PREF_SIZE);

        xAxis = new NumberAxis(xLow, xHi, xTickUnit);
        xAxis.setSide(Side.BOTTOM);
        xAxis.setMinorTickVisible(false);
        xAxis.setTickMarkVisible(true);
        xAxis.setPrefWidth(width);
        xAxis.setLayoutY(height / 2);

        yAxis = new NumberAxis(yLow, yHi, yTickUnit);
        yAxis.setSide(Side.LEFT);
        yAxis.setMinorTickVisible(false);
        yAxis.setTickMarkVisible(true);
        yAxis.setPrefHeight(height);
        yAxis.layoutXProperty().bind(
                Bindings.subtract(
                        (width / 2) + 1,
                        yAxis.widthProperty()
                )
        );


        getChildren().setAll(xAxis, yAxis);
    }

    /**
     * Getter pentru Ox
     *
     * @return: axa Ox
     */
    public NumberAxis getXAxis() {
        return xAxis;
    }

    /**
     * Getter pentru Oy
     *
     * @return: axa Oy
     */
    public NumberAxis getYAxis() {
        return yAxis;
    }
}
